"""
ai_response_generator.py - GÉNÉRATION DE RÉPONSES AVEC IA

🎯 REMPLACE: 400+ templates hardcodés par génération IA intelligente
🚀 CAPACITÉS:
- ✅ Génération contextuelle basée sur entités fusionnées
- ✅ Réponses précises avec données de poids calculées
- ✅ Adaptation automatique au niveau technique utilisateur
- ✅ Support multilingue natif
- ✅ Intégration seamless des weight_data du classifier
- ✅ Templates d'urgence comme fallback

Architecture:
- Prompts spécialisés par type de réponse
- Génération adaptée au contexte utilisateur  
- Intégration des données techniques (poids, seuils)
- Validation qualité automatique
- Fallback robuste vers templates
"""

import json
import logging
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass
from datetime import datetime

from .ai_service_manager import AIServiceType, call_ai, AIResponse

logger = logging.getLogger(__name__)

@dataclass
class ResponseData:
    """Structure d'une réponse générée"""
    content: str
    response_type: str
    confidence: float
    reasoning: str = ""
    weight_data_used: bool = False
    language: str = "fr"
    generation_method: str = "ai"  # ai, template, hybrid
    
    # Métriques qualité
    word_count: int = 0
    technical_level: str = "intermediate"
    includes_recommendations: bool = False
    includes_values: bool = False
    
    def __post_init__(self):
        self.word_count = len(self.content.split()) if self.content else 0
        self.includes_recommendations = "conseil" in self.content.lower() or "recommand" in self.content.lower()
        self.includes_values = any(char.isdigit() for char in self.content)

class AIResponseGenerator:
    """Générateur de réponses avec IA - Remplace les templates hardcodés"""
    
    def __init__(self):
        # Configuration des modèles par type de réponse
        self.models = {
            "contextual": "gpt-4",        # Réponses contextuelles précises
            "general": "gpt-4",           # Réponses générales
            "clarification": "gpt-3.5-turbo",  # Clarifications simples
            "technical": "gpt-4",         # Réponses techniques avancées
            "multilingual": "gpt-4"       # Support multilingue
        }
        
        # Prompts spécialisés
        self.prompts = self._initialize_prompts()
        
        # Templates d'urgence (fallback minimal)
        self.emergency_templates = self._initialize_emergency_templates()
        
        # Critères de qualité
        self.quality_thresholds = {
            "min_word_count": 30,
            "max_word_count": 400,
            "min_confidence": 0.6,
            "required_elements": ["practical_info", "professional_tone"]
        }
        
        logger.info("🤖 [AI Response Generator] Initialisé avec génération IA avancée")
    
    def _initialize_prompts(self) -> Dict[str, str]:
        """Initialise les prompts spécialisés par type de réponse"""
        return {
            "contextual_precise": """Tu es un vétérinaire avicole expert. Génère une réponse précise et professionnelle.

QUESTION: "{question}"

ENTITÉS FUSIONNÉES:
{merged_entities}

DONNÉES DE POIDS CALCULÉES:
{weight_data}

CONTEXTE: Cette question fait suite à une conversation où l'utilisateur a fourni des clarifications.

INSTRUCTIONS:
1. **UTILISE les données de poids** pour donner des valeurs précises
2. **RÉPONDS de manière directe** - l'utilisateur a déjà précisé sa question
3. **INCLUS des fourchettes** avec les seuils d'alerte
4. **DONNE des conseils pratiques** de surveillance
5. **RESTE concis** mais complet (150-250 mots)

STRUCTURE ATTENDUE:
- Réponse directe à la question
- Fourchette de poids normale avec seuils
- Conseils de surveillance pratiques
- Recommandations si nécessaire

EXEMPLE DE RÉPONSE:
"🎯 **Ross 308 mâle à 10 jours : 187-235g**

**Fourchette normale :** 190-235g (avec bonus mâle +12%)
**Seuils d'alerte :** 
• < 187g : Surveillance renforcée recommandée
• > 270g : Croissance excessive possible

**Conseils pratiques :**
• Pesée d'échantillon (10-15 sujets) pour vérifier l'homogénéité
• Contrôle quotidien de l'appétit et de l'activité
• Ajustement alimentaire si écarts persistants

Cette fourchette correspond aux standards Ross 308 pour cette race à croissance rapide."

Génère maintenant ta réponse professionnelle:""",

            "general_informative": """Tu es un vétérinaire avicole expert qui génère des réponses générales utiles et professionnelles.

QUESTION: "{question}"

ENTITÉS DISPONIBLES:
{entities}

CONTEXTE: Question générale nécessitant informations pratiques avec standards.

INSTRUCTIONS:
1. **FOURNIS des informations pratiques** avec fourchettes de valeurs
2. **INCLUS les variations** selon race, âge, sexe
3. **DONNE des conseils concrets** de gestion
4. **RESTE accessible** mais professionnel
5. **PROPOSE précision** si informations manquantes

STRUCTURE:
- Réponse informative générale
- Fourchettes de valeurs standards  
- Facteurs de variation (race, âge, sexe)
- Conseils pratiques
- Offre de précision si plus d'infos

EXEMPLE:
"**Poids des poulets à 10 jours :**

📊 **Fourchettes générales** :
• **Races lourdes** (Ross 308, Cobb 500) : 170-210g
• **Races standard** : 150-190g
• **Races pondeuses** : 130-170g

⚖️ **Variations importantes** :
• **Mâles** : +10-15% par rapport aux moyennes
• **Femelles** : -10-15% par rapport aux moyennes

🎯 **Surveillance recommandée** :
• Pesée hebdomadaire d'échantillon représentatif
• Contrôle homogénéité du troupeau
• Ajustement alimentaire selon évolution

💡 **Pour une réponse plus précise**, précisez la race et le sexe de vos animaux."

Génère maintenant ta réponse:""",

            "clarification_request": """Tu es un expert avicole qui guide l'utilisateur pour obtenir les informations nécessaires.

QUESTION INCOMPLÈTE: "{question}"

ENTITÉS MANQUANTES: {missing_entities}

CONTEXTE: L'utilisateur a posé une question où je peux donner une réponse utile même partielle.

INSTRUCTIONS:
1. **DONNE D'ABORD UNE RÉPONSE UTILE** basée sur les informations disponibles
2. **PUIS DEMANDE précisions** pour affiner la réponse
3. **GUIDE CONCRÈTEMENT** avec exemples
4. **RESTE POSITIF** et professionnel
5. **STRUCTURE CLAIRE** : réponse utile + demande précisions

STRUCTURE OBLIGATOIRE:
- Réponse informative générale basée sur la question
- Fourchettes ou conseils généraux applicables
- Puis demande de précisions pour affiner
- Exemples concrets de précisions utiles

EXEMPLE:
"**Poids des poulets à 6 jours :**

Pour un poulet de 6 jours, le poids varie généralement entre 80-120g selon la race et le sexe. Les races de chair (Ross 308, Cobb 500) sont plus lourdes (90-130g) que les races pondeuses (70-100g).

**Pour une réponse plus précise**, précisez :
• **Race/souche** : Ross 308, Cobb 500, Hubbard, etc.
• **Sexe** : Mâles, femelles, ou troupeau mixte

Ces informations me permettront de vous donner des fourchettes de poids spécifiques à votre situation."

Génère maintenant ta réponse avec information utile + demande précisions:""",

            "technical_detailed": """Tu es un vétérinaire avicole expert fournissant une réponse technique approfondie.

QUESTION TECHNIQUE: "{question}"

ENTITÉS: {entities}

CONTEXTE: Question nécessitant une expertise technique avancée.

INSTRUCTIONS:
1. **NIVEAU EXPERT** - utilise terminologie professionnelle
2. **DÉTAILS TECHNIQUES** - mécanismes, causes, solutions
3. **DONNÉES PRÉCISES** - chiffres, standards, protocoles
4. **RÉFÉRENCES** - mention de bonnes pratiques
5. **RECOMMANDATIONS** - actions concrètes

STRUCTURE:
- Analyse technique du problème/question
- Données et standards professionnels
- Mécanismes/causes sous-jacents
- Recommandations protocoles
- Suivi et monitoring

Génère une réponse technique approfondie:""",

            "health_emergency": """Tu es un vétérinaire qui répond à une situation potentiellement urgente.

QUESTION SANTÉ: "{question}"

SYMPTÔMES: {symptoms}

CONTEXTE: Possible problème de santé nécessitant attention.

INSTRUCTIONS:
1. **URGENCE** - évalue le niveau de priorité
2. **CONSEILS IMMÉDIATS** - actions à prendre rapidement
3. **SIGNAUX D'ALARME** - quand consulter d'urgence
4. **MESURES** - isolement, traitement symptomatique
5. **CONSULTATION** - recommande suivi vétérinaire

STRUCTURE:
- Évaluation urgence
- Actions immédiates
- Signaux d'alarme
- Mesures conservatoires
- Recommandation consultation

⚠️ **IMPORTANT**: Recommande TOUJOURS consultation vétérinaire pour problèmes de santé.

Génère une réponse orientée santé:"""
        }
    
    def _initialize_emergency_templates(self) -> Dict[str, str]:
        """Templates d'urgence en cas d'échec IA"""
        return {
            "fr": {
                "general": "Pour votre question sur l'élevage avicole, les standards varient selon la race, l'âge et le sexe des animaux. Je recommande de consulter un spécialiste avicole ou un vétérinaire pour des conseils personnalisés à votre situation spécifique.",
                "performance": "Les performances d'élevage dépendent de nombreux facteurs : race, âge, sexe, conditions d'élevage. Les fourchettes générales varient significativement. Pour une réponse précise, précisez ces éléments ou consultez un technicien avicole.",
                "health": "Pour tout problème de santé de vos volailles, je recommande fortement de consulter un vétérinaire rapidement. Les symptômes peuvent évoluer vite et nécessiter un diagnostic professionnel et un traitement adapté."
            },
            "en": {
                "general": "For your poultry farming question, standards vary by breed, age and sex. I recommend consulting a poultry specialist or veterinarian for advice tailored to your specific situation.",
                "performance": "Performance standards depend on many factors: breed, age, sex, housing conditions. General ranges vary significantly. For precise information, specify these elements or consult a poultry technician.",
                "health": "For any health issues with your poultry, I strongly recommend consulting a veterinarian promptly. Symptoms can evolve quickly and require professional diagnosis and appropriate treatment."
            }
        }
    
    async def generate_contextual_response(self, 
                                         question: str,
                                         merged_entities: Dict[str, Any],
                                         weight_data: Dict[str, Any] = None,
                                         conversation_context: str = "",
                                         language: str = "fr") -> ResponseData:
        """
        Génère une réponse contextuelle précise avec données de poids
        
        Args:
            question: Question de l'utilisateur (possiblement enhanced)
            merged_entities: Entités fusionnées du contexte
            weight_data: Données de poids calculées par le classifier
            conversation_context: Contexte conversationnel
            language: Langue de génération
            
        Returns:
            ResponseData avec réponse générée
        """
        try:
            logger.info(f"🤖 [AI Response Generator] Génération contextuelle: '{question[:50]}...'")
            
            # Préparer les données pour le prompt
            entities_str = json.dumps(merged_entities, ensure_ascii=False, indent=2)
            weight_str = json.dumps(weight_data or {}, ensure_ascii=False, indent=2) if weight_data else "Aucune donnée de poids disponible"
            
            # Choisir le prompt selon le contenu
            if weight_data and weight_data.get("weight_range"):
                prompt_template = self.prompts["contextual_precise"]
            else:
                prompt_template = self.prompts["general_informative"]
            
            # Construire le prompt final
            prompt = prompt_template.format(
                question=question,
                merged_entities=entities_str,
                weight_data=weight_str
            )
            
            # Appel IA pour génération
            ai_response = await call_ai(
                service_type=AIServiceType.RESPONSE_GENERATION,
                prompt=prompt,
                model=self.models["contextual"],
                max_tokens=600,
                temperature=0.3,  # Créativité modérée pour réponses naturelles
                cache_key=f"contextual_response_{hash(question + entities_str)}"
            )
            
            # Valider la qualité de la réponse
            response_content = ai_response.content.strip()
            quality_score = self._assess_response_quality(response_content, weight_data)
            
            # Construire ResponseData
            response_data = ResponseData(
                content=response_content,
                response_type="contextual_answer",
                confidence=quality_score,
                reasoning="Réponse contextuelle générée avec IA",
                weight_data_used=bool(weight_data),
                language=language,
                generation_method="ai",
                technical_level=self._detect_technical_level(merged_entities)
            )
            
            logger.info(f"✅ [AI Response Generator] Réponse contextuelle générée: {quality_score:.2f} qualité, {response_data.word_count} mots")
            
            return response_data
            
        except Exception as e:
            logger.error(f"❌ [AI Response Generator] Erreur génération contextuelle: {e}")
            return self._generate_emergency_response(question, "contextual", language, str(e))
    
    async def generate_general_response(self,
                                      question: str,
                                      entities: Dict[str, Any],
                                      missing_entities: List[str] = None,
                                      language: str = "fr") -> ResponseData:
        """
        Génère une réponse générale informative avec offre de précision
        
        Args:
            question: Question de l'utilisateur
            entities: Entités extraites disponibles
            missing_entities: Entités manquantes pour précision
            language: Langue de génération
            
        Returns:
            ResponseData avec réponse générale
        """
        try:
            logger.info(f"🤖 [AI Response Generator] Génération générale: '{question[:50]}...'")
            
            # Préparer les données
            entities_str = json.dumps(entities, ensure_ascii=False, indent=2)
            
            # Construire le prompt
            prompt = self.prompts["general_informative"].format(
                question=question,
                entities=entities_str
            )
            
            # Génération IA
            ai_response = await call_ai(
                service_type=AIServiceType.RESPONSE_GENERATION,
                prompt=prompt,
                model=self.models["general"],
                max_tokens=500,
                temperature=0.3,
                cache_key=f"general_response_{hash(question + entities_str)}"
            )
            
            # Évaluer qualité
            response_content = ai_response.content.strip()
            quality_score = self._assess_response_quality(response_content)
            
            response_data = ResponseData(
                content=response_content,
                response_type="general_answer",
                confidence=quality_score,
                reasoning="Réponse générale avec informations pratiques",
                language=language,
                generation_method="ai"
            )
            
            logger.info(f"✅ [AI Response Generator] Réponse générale générée: {quality_score:.2f} qualité")
            
            return response_data
            
        except Exception as e:
            logger.error(f"❌ [AI Response Generator] Erreur génération générale: {e}")
            return self._generate_emergency_response(question, "general", language, str(e))
    
    async def generate_clarification_request(self,
                                           question: str,
                                           missing_entities: List[str],
                                           available_entities: Dict[str, Any] = None,
                                           language: str = "fr") -> ResponseData:
        """
        Génère une demande de clarification guidée
        
        Args:
            question: Question originale incomplète
            missing_entities: Entités manquantes
            available_entities: Entités déjà disponibles
            language: Langue de génération
            
        Returns:
            ResponseData avec clarification
        """
        try:
            logger.info(f"🤖 [AI Response Generator] Génération clarification: manquants={missing_entities}")
            
            # Préparer les données
            missing_str = ", ".join(missing_entities) if missing_entities else "informations contextuelles"
            
            # Construire le prompt
            prompt = self.prompts["clarification_request"].format(
                question=question,
                missing_entities=missing_str
            )
            
            # Génération IA
            ai_response = await call_ai(
                service_type=AIServiceType.RESPONSE_GENERATION,
                prompt=prompt,
                model=self.models["clarification"],
                max_tokens=400,
                temperature=0.2,  # Plus conservateur pour clarifications
                cache_key=f"clarification_{hash(question + missing_str)}"
            )
            
            response_content = ai_response.content.strip()
            quality_score = self._assess_clarification_quality(response_content)
            
            response_data = ResponseData(
                content=response_content,
                response_type="needs_clarification",
                confidence=quality_score,
                reasoning="Clarification guidée générée avec IA",
                language=language,
                generation_method="ai"
            )
            
            logger.info(f"✅ [AI Response Generator] Clarification générée: {quality_score:.2f} qualité")
            
            return response_data
            
        except Exception as e:
            logger.error(f"❌ [AI Response Generator] Erreur génération clarification: {e}")
            return self._generate_emergency_response(question, "clarification", language, str(e))
    
    async def generate_health_response(self,
                                     question: str,
                                     symptoms: List[str],
                                     entities: Dict[str, Any] = None,
                                     language: str = "fr") -> ResponseData:
        """
        Génère une réponse spécialisée santé avec recommandations
        
        Args:
            question: Question de santé
            symptoms: Symptômes identifiés
            entities: Entités contextuelles
            language: Langue de génération
            
        Returns:
            ResponseData avec réponse santé
        """
        try:
            logger.info(f"🤖 [AI Response Generator] Génération santé: {len(symptoms)} symptômes")
            
            # Préparer les données
            symptoms_str = ", ".join(symptoms) if symptoms else "symptômes non spécifiés"
            
            # Construire le prompt
            prompt = self.prompts["health_emergency"].format(
                question=question,
                symptoms=symptoms_str
            )
            
            # Génération IA avec modèle expert
            ai_response = await call_ai(
                service_type=AIServiceType.RESPONSE_GENERATION,
                prompt=prompt,
                model=self.models["technical"],
                max_tokens=500,
                temperature=0.1,  # Très conservateur pour santé
                cache_key=f"health_response_{hash(question + symptoms_str)}"
            )
            
            response_content = ai_response.content.strip()
            
            # Vérifier que la réponse recommande consultation vétérinaire
            if "vétérinaire" not in response_content.lower() and "veterinarian" not in response_content.lower():
                response_content += "\n\n⚠️ **Important** : Consultez un vétérinaire pour tout problème de santé persistant ou grave."
            
            quality_score = self._assess_response_quality(response_content)
            
            response_data = ResponseData(
                content=response_content,
                response_type="health_advice",
                confidence=quality_score,
                reasoning="Réponse santé avec recommandation vétérinaire",
                language=language,
                generation_method="ai",
                technical_level="expert"
            )
            
            logger.info(f"✅ [AI Response Generator] Réponse santé générée: {quality_score:.2f} qualité")
            
            return response_data
            
        except Exception as e:
            logger.error(f"❌ [AI Response Generator] Erreur génération santé: {e}")
            return self._generate_emergency_response(question, "health", language, str(e))
    
    def _assess_response_quality(self, content: str, weight_data: Dict[str, Any] = None) -> float:
        """Évalue la qualité d'une réponse générée"""
        
        if not content or len(content.strip()) < 20:
            return 0.0
        
        quality_score = 0.7  # Base
        
        # Longueur appropriée
        word_count = len(content.split())
        if self.quality_thresholds["min_word_count"] <= word_count <= self.quality_thresholds["max_word_count"]:
            quality_score += 0.1
        
        # Contient des valeurs numériques (fourchettes, données)
        if any(char.isdigit() for char in content):
            quality_score += 0.1
        
        # Utilise les données de poids si disponibles
        if weight_data and weight_data.get("weight_range"):
            weight_range = weight_data["weight_range"]
            if str(weight_range[0]) in content and str(weight_range[1]) in content:
                quality_score += 0.2
        
        # Structure professionnelle (emojis, sections)
        if "**" in content or "•" in content or "📊" in content:
            quality_score += 0.1
        
        # Conseils pratiques
        if any(word in content.lower() for word in ["conseil", "recommand", "surveil", "contrôl"]):
            quality_score += 0.1
        
        return min(quality_score, 1.0)
    
    def _assess_clarification_quality(self, content: str) -> float:
        """Évalue la qualité d'une clarification"""
        
        quality_score = 0.6  # Base pour clarifications
        
        # Contient des exemples
        if "exemple" in content.lower() or "ex:" in content.lower():
            quality_score += 0.1
        
        # Guide concrètement  
        if "précis" in content.lower() or "spécifi" in content.lower():
            quality_score += 0.1
        
        # Ton positif (pas de "ne peux pas")
        if "ne peux pas" not in content.lower() and "cannot" not in content.lower():
            quality_score += 0.1
        
        # Structure claire
        if "**" in content and ("•" in content or ":" in content):
            quality_score += 0.1
        
        return min(quality_score, 1.0)
    
    def _detect_technical_level(self, entities: Dict[str, Any]) -> str:
        """Détecte le niveau technique requis"""
        
        # Présence d'entités précises → utilisateur informé
        specific_count = sum(1 for v in entities.values() if v is not None)
        
        if specific_count >= 3:
            return "advanced"
        elif specific_count >= 1:
            return "intermediate"
        else:
            return "beginner"
    
    def _generate_emergency_response(self, question: str, response_type: str, language: str, error: str) -> ResponseData:
        """Génère une réponse d'urgence en cas d'échec IA"""
        
        templates = self.emergency_templates.get(language, self.emergency_templates["fr"])
        
        # Choisir template selon type
        if "santé" in question.lower() or "health" in question.lower() or response_type == "health":
            template_key = "health"
        elif any(word in question.lower() for word in ["poids", "croissance", "performance", "weight"]):
            template_key = "performance"
        else:
            template_key = "general"
        
        emergency_content = templates.get(template_key, templates["general"])
        
        return ResponseData(
            content=emergency_content,
            response_type=response_type,
            confidence=0.3,
            reasoning=f"Réponse d'urgence - Erreur IA: {error}",
            language=language,
            generation_method="emergency_template"
        )
    
    def get_generation_stats(self) -> Dict[str, Any]:
        """Statistiques de génération pour monitoring"""
        from .ai_service_manager import get_ai_service_manager
        
        manager = get_ai_service_manager()
        health = manager.get_service_health()
        
        return {
            "service_name": "AI Response Generator",
            "generation_requests": health.get("requests_by_service", {}).get("response_generation", 0),
            "models_available": list(self.models.keys()),
            "response_types": ["contextual_answer", "general_answer", "needs_clarification", "health_advice"],
            "quality_thresholds": self.quality_thresholds,
            "emergency_templates": {lang: len(templates) for lang, templates in self.emergency_templates.items()},
            "ai_service_health": health
        }

# Instance globale pour utilisation facile
_ai_response_generator = None

def get_ai_response_generator() -> AIResponseGenerator:
    """Récupère l'instance singleton du générateur IA"""
    global _ai_response_generator
    if _ai_response_generator is None:
        _ai_response_generator = AIResponseGenerator()
    return _ai_response_generator