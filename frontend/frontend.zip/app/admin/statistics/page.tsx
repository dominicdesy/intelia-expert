'use client'

import { StatisticsPage } from '../../chat/components/StatisticsPage'

export default function AdminStatisticsRoute() {
  return <StatisticsPage />
}