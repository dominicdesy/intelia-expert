// lib/supabase/client.ts – CLIENT SUPABASE SÉCURISÉ (timeout 25s) + DEBUG + SINGLETON
'use client'

// ✅ CHANGEMENT CRITIQUE: Utiliser le singleton au lieu de créer de nouvelles instances
import { getSupabaseClient, resetSupabaseClient } from './singleton'
import type { Database } from '@/types/supabase'

// ✅ EXPORT DU CLIENT SINGLETON au lieu de createClientComponentClient
export const supabase = getSupabaseClient()

// Configuration env (conservée pour compatibilité)
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

if (!SUPABASE_URL) throw new Error('Missing env.NEXT_PUBLIC_SUPABASE_URL')
if (!SUPABASE_ANON_KEY) throw new Error('Missing env.NEXT_PUBLIC_SUPABASE_ANON_KEY')

// ---- DEBUG (conservé tel quel) ----
const SUPABASE_DEBUG = (
  (typeof window !== 'undefined' && (
    localStorage.getItem('SUPABASE_DEBUG') === '1' ||
    localStorage.getItem('AUTH_DEBUG') === '1'
  )) || process.env.NEXT_PUBLIC_SUPABASE_DEBUG === '1' || process.env.NEXT_PUBLIC_AUTH_DEBUG === '1'
)

const slog = (...args: any[]) => {
  if (SUPABASE_DEBUG) {
    if (typeof window !== 'undefined') console.debug('[SupabaseClient/Singleton]', ...args)
    else console.debug('[SupabaseClient/Singleton/SSR]', ...args)
  }
}

slog('✅ Loaded client.ts (supabase singleton client ready)', { url: SUPABASE_URL })

// ⏳ fetch avec timeout (conservé tel quel)
let __fetchSeq = 0
export const fetchWithTimeout = (ms: number = 45000) => {
  return async (input: RequestInfo | URL, init: RequestInit = {}) => {
    const idNum = ++__fetchSeq
    const start = typeof performance !== 'undefined' && performance.now ? performance.now() : Date.now()
    const controller = new AbortController()
    try {
      controller.signal.addEventListener('abort', () => {
        try { slog(`#${idNum} ⚠️ signal aborted`, (controller as any)?.signal?.reason || '(no reason)') } catch {}
      })
    } catch {}
    const to = setTimeout(() => {
      const reason = new Error(`timeout:${ms}ms`)
      try { (controller as any).abort(reason) } catch { controller.abort() }
      try {
        slog(`#${idNum} ⏱️ ABORT after ${ms}ms`, { reason: reason.message, url: (input as any)?.toString?.() ?? String(input) })
      } catch {}
    }, ms)

    try {
      slog(`#${idNum} ↗ fetch start`, (input as any)?.toString?.() ?? String(input), { timeout_ms: ms })
      const res = await fetch(input, { ...init, signal: controller.signal })
      const dur = Math.round(((typeof performance !== 'undefined' && performance.now ? performance.now() : Date.now()) - start))
      slog(`#${idNum} ↙ fetch end`, { status: (res as any)?.status, duration_ms: dur })
      return res
    } catch (e) {
      const dur = Math.round(((typeof performance !== 'undefined' && performance.now ? performance.now() : Date.now()) - start))
      slog(`#${idNum} ✖ fetch error after ${dur}ms`, e)
      throw e
    } finally {
      clearTimeout(to)
    }
  }
}

// ✅ CHANGEMENT: supabaseAuth utilise maintenant le singleton avec fetch temporisé
// Au lieu de créer une nouvelle instance, on utilise le singleton existant
export const supabaseAuth = getSupabaseClient()

slog('🔐 supabaseAuth using singleton (no new instance created)')

// —— Helpers d'auth (conservés mais utilisent le singleton) ——
export const auth = {
  async getSession() {
    // ✅ Utilise le singleton
    const client = getSupabaseClient()
    const { data } = await client.auth.getSession()
    slog('getSession ↦', !!data?.session)
    return data?.session || null
  },

  async getAccessToken() {
    const session = await this.getSession()
    const token = session?.access_token || null
    slog('getAccessToken ↦', token ? 'present' : 'null')
    return token
  },

  async logout() {
    try {
      slog('logout() called')
      // ✅ Utilise le singleton
      const client = getSupabaseClient()
      const { error } = await client.auth.signOut()
      if (error) throw error
      try { localStorage.removeItem('intelia-chat-storage') } catch {}
      slog('logout() ↦ success')
      return { success: true }
    } catch (error) {
      console.error('❌ Erreur déconnexion:', error)
      return { success: false, error }
    }
  },
}

// —— Requêtes sécurisées (conservées, utilisent auth.getAccessToken qui utilise le singleton) ——
export const secureRequest = {
  async get(url: string, options: RequestInit = {}) {
    const token = await auth.getAccessToken()
    if (!token) throw new Error('Non authentifié')
    slog('secure GET', url)
    return fetch(url, {
      ...options,
      headers: { 'Authorization': `Bearer ${token}`, ...(options.headers || {}) },
      method: 'GET',
    })
  },
  async post(url: string, data: any, options: RequestInit = {}) {
    const token = await auth.getAccessToken()
    if (!token) throw new Error('Non authentifié')
    slog('secure POST', url, { hasBody: true })
    return fetch(url, {
      ...options,
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json', ...(options.headers || {}) },
      body: JSON.stringify(data),
    })
  },
}

// ✅ NOUVELLES FONCTIONS UTILITAIRES POUR LE SINGLETON
export const getAuthHeaders = async () => {
  try {
    const client = getSupabaseClient()
    const { data: { session }, error } = await client.auth.getSession()
    
    if (error) {
      console.error('❌ [client] Erreur récupération session:', error.message)
      return {
        'Content-Type': 'application/json',
      }
    }

    if (!session?.access_token) {
      console.warn('⚠️ [client] Aucun token d\'accès disponible')
      return {
        'Content-Type': 'application/json',
      }
    }

    console.log('✅ [client] Token Supabase récupéré avec succès (singleton)')
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session.access_token}`,
      'X-Supabase-Auth': 'true',
    }
  } catch (error) {
    console.error('❌ [client] Erreur getAuthHeaders (singleton):', error)
    return {
      'Content-Type': 'application/json',
    }
  }
}

// ✅ FONCTION POUR RÉINITIALISER LE SINGLETON (utile pour logout complet)
export const resetClient = () => {
  resetSupabaseClient()
  slog('🔄 Client singleton réinitialisé')
}

// Export par défaut (utilise le singleton)
export default supabase