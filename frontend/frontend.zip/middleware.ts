// middleware.ts - Version Supabase mise à jour

import { createMiddlewareClient } from '@supabase/auth-helpers-nextjs'
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  
  try {
    const supabase = createMiddlewareClient({ req, res })
    const { data: { session } } = await supabase.auth.getSession()

    console.log('🔄 [Middleware] Vérification Supabase:', {
      path: req.nextUrl.pathname,
      hasSession: !!session,
      userEmail: session?.user?.email
    })

    const { pathname } = req.nextUrl

    // 🆕 REDIRECTION /welcome → /auth/invitation (NOUVEAU)
    if (pathname === '/welcome' || pathname === '/welcome/') {
      console.log('🔄 [Middleware] Redirection /welcome → /auth/invitation')
      
      // Construire la nouvelle URL avec tous les paramètres préservés
      const invitationUrl = new URL('/auth/invitation', req.url)
      
      // Copier les query parameters (?invited_by=...)
      req.nextUrl.searchParams.forEach((value, key) => {
        invitationUrl.searchParams.set(key, value)
      })
      
      console.log('✅ [Middleware] Redirection vers:', invitationUrl.toString())
      return NextResponse.redirect(invitationUrl)
    }

    // 🚨 GESTION SPÉCIALE POUR DÉCONNEXION - CONSERVÉE
    if (pathname === '/auth/logout') {
      console.log('🚪 [Middleware] Route logout détectée - nettoyage forcé')
      
      // Déconnecter via Supabase
      await supabase.auth.signOut()
      
      // Créer une réponse de redirection vers login
      const loginUrl = new URL('/auth/login', req.url)
      loginUrl.searchParams.set('auth', 'logout')
      const logoutResponse = NextResponse.redirect(loginUrl)
      
      // Nettoyer tous les cookies d'auth dans la réponse
      const cookiesToClear = [
        'supabase-auth-token',
        'supabase.auth.token', 
        'sb-access-token',
        'sb-refresh-token',
        // Cookies Supabase spécifiques au projet
        'sb-' + process.env.NEXT_PUBLIC_SUPABASE_URL?.split('//')[1]?.split('.')[0] + '-auth-token'
      ]
      
      cookiesToClear.forEach(cookieName => {
        logoutResponse.cookies.delete(cookieName)
        // Aussi marquer comme expiré
        logoutResponse.cookies.set(cookieName, '', { 
          expires: new Date(0),
          path: '/',
          domain: req.nextUrl.hostname
        })
      })
      
      console.log('✅ [Middleware] Redirection logout avec nettoyage cookies Supabase')
      return logoutResponse
    }

    // Routes publiques (conservé de votre logique + ajout invitation)
    const publicRoutes = [
      '/auth/login',
      '/auth/signup', 
      '/auth/forgot-password',
      '/auth/reset-password',
      '/auth/confirm',
      '/auth/callback', // 🆕 AJOUT: Route callback Supabase
      '/auth/invitation', // 🆕 AJOUT: Route invitation
      '/privacy',
      '/terms',
      '/',  // Page d'accueil publique
      '/_next',
      '/favicon.ico',
      '/images',
      '/icons'
    ]

    const isPublicRoute = publicRoutes.some(route => 
      pathname.startsWith(route) || pathname === route
    )

    // Si route publique, appliquer les headers de sécurité et continuer
    if (isPublicRoute) {
      const secureResponse = applySecurityHeaders(res)
      return secureResponse
    }

    // Routes protégées (conservé de votre logique)
    const protectedPaths = ['/chat', '/profile', '/settings', '/admin']
    const isProtectedPath = protectedPaths.some(path => 
      pathname.startsWith(path)
    )

    // ✅ CORRECTION PRINCIPALE: Redirection PROPRE sans paramètres indésirables
    if (isProtectedPath && !session) {
      console.log('🚫 [Middleware] Accès refusé à route protégée:', pathname)
      console.log('🏠 [Middleware] Redirection vers accueil SANS paramètres')
      
      // ✅ REDIRECTION PROPRE vers l'accueil (conservé de votre logique)
      const homeUrl = new URL('/', req.url)
      return NextResponse.redirect(homeUrl)
    }

    // ✅ ÉVITER LES REDIRECTIONS INUTILES pour les utilisateurs connectés
    if (pathname === '/' && session) {
      console.log('✅ [Middleware] Utilisateur connecté sur accueil - Pas de redirection forcée')
      // Laisser l'utilisateur sur la page d'accueil, ne pas forcer vers /chat
    }

    // 🆕 NOUVEAU: Redirection des pages d'auth vers chat si connecté
    if (pathname.startsWith('/auth/') && session && pathname !== '/auth/callback' && pathname !== '/auth/invitation') {
      console.log('🔄 [Middleware] Utilisateur connecté sur page auth, redirection vers chat')
      return NextResponse.redirect(new URL('/chat', req.url))
    }

    // Headers de sécurité conservés pour Zoho SalesIQ
    const secureResponse = applySecurityHeaders(res)
    return secureResponse

  } catch (error) {
    console.error('❌ [Middleware] Erreur Supabase:', error)
    return NextResponse.next()
  }
}

// Fonction pour appliquer vos headers de sécurité existants (VERSION COMPLÈTE RESTAURÉE)
function applySecurityHeaders(response: NextResponse): NextResponse {
  const cspHeader = [
    "default-src 'self'",
    // ✅ SCRIPT-SRC CORRIGÉ pour autoriser Zoho SalesIQ
    "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdnjs.cloudflare.com https://salesiq.zohopublic.com https://*.zoho.com https://*.zohostatic.com https://*.zohocdn.com",
    // ✅ STYLE-SRC CORRIGÉ pour autoriser Zoho SalesIQ  
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://salesiq.zohopublic.com https://*.zoho.com https://*.zohostatic.com https://*.zohocdn.com",
    "font-src 'self' https://fonts.gstatic.com https://*.zoho.com https://*.zohostatic.com https://*.zohocdn.com",
    // ✅ IMG-SRC CORRIGÉ pour autoriser Zoho SalesIQ
    "img-src 'self' data: https: blob: https://salesiq.zohopublic.com https://*.zoho.com https://*.zohostatic.com https://*.zohocdn.com",
    // ✅ CONNECT-SRC CORRIGÉ - AJOUT DE RESTCOUNTRIES.COM + conservation de tout le reste
    "connect-src 'self' https://*.supabase.co https://expert-app-cngws.ondigitalocean.app https://salesiq.zohopublic.com https://*.zoho.com wss://*.zoho.com wss://vts.zohopublic.com wss://salesiq.zohopublic.com https://*.zohostatic.com https://restcountries.com",
    // ✅ FRAME-SRC CONSERVÉ pour autoriser les iframes Zoho
    "frame-src 'self' https://salesiq.zohopublic.com https://*.zoho.com",
    // ✅ CHILD-SRC CONSERVÉ pour autoriser les pop-ups Zoho
    "child-src 'self' https://salesiq.zohopublic.com https://*.zoho.com",
    // ✅ WORKER-SRC CONSERVÉ pour les service workers
    "worker-src 'self' blob:",
    "media-src 'self' https://*.zoho.com",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    "upgrade-insecure-requests"
  ].join('; ')

  response.headers.set('Content-Security-Policy', cspHeader)
  response.headers.set('X-Frame-Options', 'DENY')
  response.headers.set('X-Content-Type-Options', 'nosniff')
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')
  response.headers.set('X-XSS-Protection', '1; mode=block')
  
  return response
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|images|icons|.*\\.png$|.*\\.jpg$|.*\\.svg$|.*\\.ico$).*)',
  ],
}